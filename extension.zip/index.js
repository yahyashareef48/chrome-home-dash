import { App } from "./app.js";
// Initialize app when DOM is ready
document.addEventListener("DOMContentLoaded", () => {
    new App();
});
