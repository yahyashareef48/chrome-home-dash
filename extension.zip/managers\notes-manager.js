export class NotesManager {
    constructor() {
        this.notes = [];
    }
    async init() {
        await this.loadNotes();
    }
    async loadNotes() {
        const result = await chrome.storage.local.get("notes");
        this.notes = result.notes || [];
    }
    async saveNotes() {
        await chrome.storage.local.set({ notes: this.notes });
    }
    getNotes() {
        // Return notes sorted by most recently updated first
        return [...this.notes].sort((a, b) => b.updatedAt - a.updatedAt);
    }
    async addNote(title, content) {
        const note = {
            id: `note-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
            title: title.trim(),
            content: content.trim(),
            createdAt: Date.now(),
            updatedAt: Date.now(),
        };
        this.notes.push(note);
        await this.saveNotes();
        return note;
    }
    async updateNote(id, title, content) {
        const note = this.notes.find((n) => n.id === id);
        if (note) {
            note.title = title.trim();
            note.content = content.trim();
            note.updatedAt = Date.now();
            await this.saveNotes();
        }
    }
    async deleteNote(id) {
        const index = this.notes.findIndex((n) => n.id === id);
        if (index !== -1) {
            this.notes.splice(index, 1);
            await this.saveNotes();
        }
    }
    getNote(id) {
        return this.notes.find((n) => n.id === id);
    }
}
