import { ThemeStorage } from './storage';
export class ThemeManager {
    constructor() {
        this.currentTheme = null;
        this.backgroundElement = null;
        this.overlayElement = null;
        this.backgroundElement = document.getElementById('background');
        this.overlayElement = document.getElementById('overlay');
    }
    /**
     * Initialize theme manager and load saved theme
     */
    async init() {
        this.currentTheme = await ThemeStorage.load();
        this.applyTheme(this.currentTheme);
        // Listen for theme changes from other tabs
        ThemeStorage.onChange((config) => {
            this.currentTheme = config;
            this.applyTheme(config);
        });
    }
    /**
     * Apply theme configuration to the page
     */
    applyTheme(config) {
        this.applyBackground(config.backgroundImage);
        this.applyColors(config.colorScheme);
        this.applyBlur(config.blurIntensity);
        this.applyOverlay(config.overlayOpacity);
    }
    /**
     * Set background image
     */
    applyBackground(image) {
        if (!this.backgroundElement)
            return;
        this.backgroundElement.style.backgroundImage = `url('${image.url}')`;
        this.backgroundElement.style.opacity = '0';
        // Fade in effect
        setTimeout(() => {
            if (this.backgroundElement) {
                this.backgroundElement.style.opacity = '1';
            }
        }, 50);
    }
    /**
     * Apply color scheme using CSS variables
     */
    applyColors(colors) {
        const root = document.documentElement;
        root.style.setProperty('--color-primary', colors.primary);
        root.style.setProperty('--color-secondary', colors.secondary);
        root.style.setProperty('--color-accent', colors.accent);
        root.style.setProperty('--color-background', colors.background);
        root.style.setProperty('--color-text', colors.text);
        root.style.setProperty('--color-text-secondary', colors.textSecondary);
    }
    /**
     * Apply blur intensity to background
     */
    applyBlur(intensity) {
        if (!this.backgroundElement)
            return;
        this.backgroundElement.style.filter = `blur(${intensity * 0.1}px)`;
    }
    /**
     * Apply overlay opacity
     */
    applyOverlay(opacity) {
        if (!this.overlayElement)
            return;
        this.overlayElement.style.opacity = (opacity / 100).toString();
    }
    /**
     * Update background image
     */
    async updateBackground(image) {
        if (!this.currentTheme)
            return;
        this.currentTheme.backgroundImage = image;
        this.applyBackground(image);
        await ThemeStorage.save(this.currentTheme);
    }
    /**
     * Update color scheme
     */
    async updateColors(colors, presetId) {
        if (!this.currentTheme)
            return;
        this.currentTheme.colorScheme = colors;
        this.currentTheme.presetId = presetId;
        this.currentTheme.useCustomColors = !presetId;
        this.applyColors(colors);
        await ThemeStorage.save(this.currentTheme);
    }
    /**
     * Update blur intensity
     */
    async updateBlur(intensity) {
        if (!this.currentTheme)
            return;
        this.currentTheme.blurIntensity = intensity;
        this.applyBlur(intensity);
        await ThemeStorage.save(this.currentTheme);
    }
    /**
     * Update overlay opacity
     */
    async updateOverlay(opacity) {
        if (!this.currentTheme)
            return;
        this.currentTheme.overlayOpacity = opacity;
        this.applyOverlay(opacity);
        await ThemeStorage.save(this.currentTheme);
    }
    /**
     * Get current theme configuration
     */
    getCurrentTheme() {
        return this.currentTheme;
    }
    /**
     * Reset to default theme
     */
    async resetTheme() {
        await ThemeStorage.reset();
        this.currentTheme = await ThemeStorage.load();
        this.applyTheme(this.currentTheme);
    }
}
